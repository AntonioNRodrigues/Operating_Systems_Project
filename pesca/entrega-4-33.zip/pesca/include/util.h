#ifndef __UTIL__
#define __UTIL__

#include <stdbool.h>

bool between (int value, int min, int max);

int min (int a, int b);

int max (int a, int b);

#endif
